import React from "react";
import Base from "../core/Base";

const AdminDashBoard = () => {
  return (
    <Base title="AdminDashBoard page">
      <h1>THis is AdminDashBoard page</h1>
    </Base>
  );
};

export default AdminDashBoard;
