import React from "react";
import "../styles.css";

export default function Home() {
  return (
    <div>
      <h1 className="text-white">Hello front end</h1>
    </div>
  );
}
