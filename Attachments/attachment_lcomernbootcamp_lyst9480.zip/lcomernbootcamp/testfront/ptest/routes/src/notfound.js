import React from "react";

export default function notfound() {
  return (
    <div>
      <h1>ERROR 404. Page not found</h1>
    </div>
  );
}
