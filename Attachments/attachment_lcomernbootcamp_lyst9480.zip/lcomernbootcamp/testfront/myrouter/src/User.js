import React from "react";

export default function User() {
  return (
    <div>
      <h1>User component</h1>
    </div>
  );
}
