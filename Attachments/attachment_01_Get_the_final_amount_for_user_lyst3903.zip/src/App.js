import React from "react";

export default function App() {
  return (
    <div>
      <h1>Hi</h1>
    </div>
  );
}
